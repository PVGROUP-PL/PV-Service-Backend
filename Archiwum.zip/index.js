// Ostateczna wersja pliku index.js

const express = require('express');
const mysql = require('mysql2/promise');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const cors = require('cors');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(express.json());

const pool = mysql.createPool({
    host: process.env.DB_HOST,
    user: process.env.DB_USER,
    password: process.env.DB_PASSWORD,
    database: process.env.DB_NAME,
    waitForConnections: true,
    connectionLimit: 10,
    queueLimit: 0,
    connectTimeout: 10000 
});

const geocode = (postalCode) => { /* ... */ };
const getDistanceInKm = (lat1, lon1, lat2, lon2) => { /* ... */ };

const authenticateToken = (req, res, next) => {
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.split(' ')[1];
    if (token == null) return res.status(401).json({ message: 'Brak tokenu autoryzacyjnego.' });
    jwt.verify(token, process.env.JWT_SECRET, (err, user) => {
        if (err) return res.status(403).json({ message: 'Token jest nieprawidłowy lub wygasł.' });
        req.user = user;
        next();
    });
};

app.post(['/api/register', '/api/register/'], async (req, res) => { /* ... */ });

// --- ZMODYFIKOWANY ENDPOINT DO LOGOWANIA ---
app.post(['/api/login', '/api/login/'], async (req, res) => {
    try {
        const { email, password } = req.body;
        if (!email || !password) return res.status(400).json({ message: 'Email i hasło są wymagane.' });

        const connection = await pool.getConnection();
        const [rows] = await connection.query('SELECT * FROM users WHERE email = ?', [email]);
        connection.release();

        if (rows.length === 0) return res.status(401).json({ message: 'Nieprawidłowy email lub hasło.' });
        
        const user = rows[0];
        const isPasswordCorrect = await bcrypt.compare(password, user.password_hash);
        if (!isPasswordCorrect) return res.status(401).json({ message: 'Nieprawidłowy email lub hasło.' });
        
        const payload = { userId: user.user_id, user_type: user.user_type };
        const token = jwt.sign(payload, process.env.JWT_SECRET, { expiresIn: '8h' });

        // --- POPRAWKA JEST TUTAJ ---
        res.status(200).json({ 
            message: 'Logowanie udane!',
            token: token,
            user: { // <-- DODAJEMY TEN OBIEKT Z DANYMI UŻYTKOWNIKA
                userId: user.user_id,
                email: user.email,
                user_type: user.user_type
            }
        });

    } catch (error) { 
        console.error("Błąd podczas logowania:", error);
        res.status(500).json({ message: 'Błąd serwera podczas logowania.' }); 
    }
});


// ... reszta endpointów bez zmian ...
app.post('/api/trucks', authenticateToken, async (req, res) => { /* ... */ });
app.put('/api/trucks/:truckId', authenticateToken, async (req, res) => { /* ... */ });
app.get('/api/trucks/my-truck', authenticateToken, async (req, res) => { /* ... */ });
app.get('/api/trucks/:truckId', async (req, res) => { /* ... */ });
app.get('/api/trucks', async (req, res) => { /* ... */ });
app.post('/api/reservations', authenticateToken, async (req, res) => { /* ... */ });


app.listen(PORT, () => {
    console.log(`🚀 Serwer uruchomiony na porcie ${PORT} i gotowy na przyjmowanie zapytań!`);
}); 